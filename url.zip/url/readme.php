 <p align="center"><font color="#DC143C">

<br/>GZ-QQ防红工具
<br/><br/>
QQ防红系统v4.2<br/><br/>


安装说明<br/>

4.2<br/>
清除旧版被别人收集接口<br/>
改用t.cn生成后缀<br/>
增加模板切换功能<br/>



4.1<br/>
直接访问 域名/install<br/>
后台添加接口域名（你做跳转站的域名）<br/>

环境要求<br/>

接口自备 cn net com 域名，其他域名不保证100%可用<br/>


<br/><br/>

QQ：995113774<br/>
官网http://www.weifenshi.com/<br/>
小高教学网www.12580sky.com<br/>
（会后续更新更多功能）<br/><br/>
</font></p>
