

<head>
<meta charset="utf-8"/>

<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, width=device-width">
<title>QQ域名防红工具 - GZ防红短链接|TX防红在线生成小工具 - 专业、好用的网址防红缩短服务</title>
<meta name="keywords" content="GZ防红,域名防红,防红短链接,QQ防报毒,微信防报毒,TX防报毒,TX防红在线生成小工具，www.txurl.cn"/>
<meta name="description" content="GZ防红,一款简单, 方便, TX防红在线生成小工具，全网第一家专注于Tx防报毒的在线工具。"/>
<link rel="shortcut icon" href="/assets/images/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="/assets/css/con_index.css">
    <script type="text/javascript" src="/assets/js/jquery.min.js" ></script>
	 <link href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="//cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
  <style>
img.logo{width:14px;height:14px;margin:0 5px 0 3px;}
body{
background:#ecedf0 url("http://pay.52qiu.la/assets/img/bj.png") fixed;
background-repeat:repeat;}
</style>
    <style media="screen">
    .art-header{z-index: 99999;width: 100%;height: 42px;background: #1787e6;position: fixed;top: 0;color: #fff;border-bottom: 1px solid #ccc;}
    .art-back{display: inline-block;float: left;height: 43px;padding-left: 10px;line-height: 43px;color: #fff;position: relative;font-size: 22px;}
    .art-title-top{width: 80%;overflow: hidden;height: 43px;position: absolute;left: 50%;font-size: 14px;font-weight: 800;transform: translateX(-50%);-webkit-transform: translateX(-50%);-moz-transform: translateX(-50%);text-align: center;line-height: 43px;}
    .art-tools{display: inline-block;float: right;height: 43px;line-height: 43px;padding: 0 20px;text-align: center;font-size: 22px;}
    .art-article{padding-top: 42px}
    .art-article-title{margin-top: 22px;padding: 0 16px;}
    .art-article-title>h1{font-weight: bold;font-size: 22px;padding: 0;margin: 0;}
    .art-information{padding: 10px 16px;line-height: 13px;font-size: 14px;}
    .art-information>span{color: #999;font-size: 13px;margin-right:4px;}
    .art-data{color: #000;line-height: 18px;}

    @media screen and (min-width: 901px) {
      html{width: 640px;margin: 0 auto;}
      .art-header{width: 641px !important;}
    }

    </style>
	 </head>
  <body>
 <div class="art-header">

 <span class="art-back"><i class="iconfont">&#xe779;</i></span>
      <span class="art-title-top">免费防红API对接文档</span>
      <span class="art-tools"><i class="iconfont">&#xe7bc;</i></span>
    </div>
    <div class="art-article">
      <div class="art-article-title">
        <h3>免费防红API对接文档</h3>
      </div>
      <div class="art-information">
        <span>发布人：GZ防红</span>
        <span> | </span>
        <span>客服QQ:<a style="font-weight: 800;color: #09f;" target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=809666838&site=qq&menu=yes">809666838</a></span>
 
 
 <hr color=red>
<div style="min-height: 300px; font-size: 14px; line-height:2;max-width: 99%;margin: 0 auto;">
<center>免费防红API对接文档</center>
提交方式：POST【参数：longurl】
<br>POST接口：http://url.jasboke.com/dwz.php
<br>提交方式:GET【参数：?longurl=】
<br>GET接口：http://url.jasboke.com/dwz.php?longurl=
<br>GET示范：http://url.jasboke.com/dwz.php?longurl=www.jasboke.com
<br><h5 style="color: blue;">代刷网主站后台可直接对接本站，极速跳转，带给用户不一样的体验！</h5>
<h4 style="color: red;">定制专属定制接口与搭建防红网站联系站长！<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=809666838&site=qq&menu=yes" class="btn btn-info btn-xs"> 联系站长</a></h4>
</div>

          <center><td align="center"><a href="/" class="btn btn-sm btn-info"><i class="glyphicon glyphicon-home"></i>返回首页</a></td></center>
</div>
　    <script type="text/javascript">
      $(".art-back").click(function(){
        window.location="/";
        //返回
      });
      $(".art-tools").click(function(){
        //更多

      });
    </script>



</div>
</div>
 </div>
   </body>
<!--?php include 'foot.php';?-->